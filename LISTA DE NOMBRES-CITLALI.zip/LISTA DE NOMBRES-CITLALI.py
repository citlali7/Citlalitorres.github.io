nombre = ("LUIS","ALEXIS","ELIAS")
i=0
while i < len (nombre):
    print (nombre[i])
i+=1
