"CITLALI BERENICE TORRES GALLEGOS"
"COVID-19"

import json
from tkinter import*

Aguas={}
Aguas['a).Covid']=[]
Aguas['a).Covid'].append({
    'Activos':9173,'Inactivos':22926,
    'Hospitalizados':179,'Defunciones':699,
    'Recuperados':7557
    })

BajCalif={}
BajCalif['b).Covid']=[]
BajCalif['b).Covid'].append({
    'Activos':349,'Inactivos':12811,
    'Hospitalizados':1564,'Defunciones':3597,
    'Recuperados':12094
    })
Camp={}
Camp['c).Covid']=[]
Camp['c).Covid'].append({
    'Activos':58,'Inactivos':142,
    'Hospitalizados':22,'Defunciones':3,
    'Recuperados':9
    })

Coah={}
Coah['d).Covid']=[]
Coah['d).Covid'].append({
    'Activos':1405,'Inactivos':1696,
    'Hospitalizados':310,'Defunciones':11,
    'Recuperados':22623
    })


EstMex={}
EstMex['e).Covid']=[]
EstMex['e).Covid'].append({
    'Activos':81532,'Inactivos':102850,
    'Hospitalizados':23235,'Defunciones':11824,
    'Recuperados':48227
    })

Guan={}
Guan['f).Covid']=[]
Guan['f).Covid'].append({
    'Activos':41063,'Inactivos':56486,
    'Hospitalizados':2553,'Defunciones':2948,
    'Recuperados':32821
    })

Guer={}
Guer['g).Covid']=[]
Guer['g).Covid'].append({
    'Activos':19146,'Inactivos':12905,
    'Hospitalizados':1126,'Defunciones':1953,
    'Recuperados':14223
    })

Hid={}
Hid['h).Covid']=[]
Hid['h).Covid'].append({
    'Activos':12853,'Inactivos':9358,
    'Hospitalizados':391,'Defunciones':1962,
    'Recuperados':7802
    })

Jal={}
Jal['i).Covid']=[]
Jal['i).Covid'].append({
    'Activos':17218,'Inactivos':36879,
    'Hospitalizados':3372,'Defunciones':3315,
    'Recuperados':17343
    })

Mich={}
Mich['j).Covid']=[]
Mich['j).Covid'].append({
    'Activos':20563,'Inactivos':27304,
    'Hospitalizados':2217,'Defunciones':1682,
    'Recuperados':15887
    })

Tam={}
Tam['k).Covid']=[]
Tam['k).Covid'].append({
    'Activos':29712,'Inactivos':36353,
    'Hospitalizados':1526,'Defunciones':2447,
    'Recuperados':25739
    })

with open('Aguascovid.json','w') as file:
    json.dump(Aguas,file)
with open('BajCalifcovid.json','w') as file:
    json.dump(BajCalif,file)
with open('Campcovid.json','w') as file:
    json.dump(Camp,file)
with open('Coahcovid.json','w') as file:
    json.dump(Coah,file)
with open('EstMexcovid.json','w') as file:
    json.dump(EstMex,file)
with open('Guancovid.json','w') as file:
    json.dump(Guan,file)
with open('Guercovid.json','w') as file:
    json.dump(Guer,file)
with open('Hidcovid.json','w') as file:
    json.dump(Hid,file)
with open('Jalcovid.json','w') as file:
    json.dump(Jal,file)
with open('Michcovid.json','w') as file:
    json.dump(Mich,file)
with open('Tamcovid.json','w') as file:
    json.dump(Tam,file)

def a():
    eti=Label(root,text=Aguas['a).Covid'])
    eti.place(x=10, y=140)
def b():
    eti=Label(root,text=BajCalif['b).Covid'])
    eti.place(x=10, y=140)
def c():
    eti=Label(root,text=Camp['c).Covid'])
    eti.place(x=10, y=140)
def d():
    eti=Label(root,text=Coah['d).Covid'])
    eti.place(x=10, y=140)
def e():
    eti=Label(root,text=EstMex['e).Covid'])
    eti.place(x=10, y=140)
def f():
    eti=Label(root,text=Guan['f).Covid'])
    eti.place(x=10, y=140)
def g():
    eti=Label(root,text=Guer['g).Covid'])
    eti.place(x=10, y=140)
def h():
    eti=Label(root,text=Hid['h).Covid'])
    eti.place(x=10, y=140)
def i():
    eti=Label(root,text=Jal['i).Covid'])
    eti.place(x=10, y=140)
def j():
    eti=Label(root,text=Mich['j).Covid'])
    eti.place(x=10, y=140)
def k():
    eti=Label(root,text=Tam['k).Covid'])
    eti.place(x=10, y=140)

root=Tk()
root.title('MEXICO COVID-19')
root.geometry('660x330')


boton=Button(root,text='Aguascalientes', command=a)
boton.place(x=10,y=10)

boton=Button(root,text='Baja California', command=b)
boton.place(x=100,y=10)

boton=Button(root,text='Campeche', command=c)
boton.place(x=190,y=10)

boton=Button(root,text='Coahuila', command=d)
boton.place(x=280,y=10)

boton=Button(root,text='Estado de Mexico', command=e)
boton.place(x=350,y=10)

boton=Button(root,text='Guanajuato', command=f)
boton.place(x=450,y=10)

boton=Button(root,text='Guerrero', command=g)
boton.place(x=10,y=50)

boton=Button(root,text='Hidalgo', command=h)
boton.place(x=80,y=50)

boton=Button(root,text='Jalisco', command=i)
boton.place(x=150,y=50)

boton=Button(root,text='Michoacan', command=j)
boton.place(x=230,y=50)

boton=Button(root,text='Tamaulipas', command=k)
boton.place(x=310,y=50)
