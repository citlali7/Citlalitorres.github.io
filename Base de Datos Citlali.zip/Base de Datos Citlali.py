#BASE DE DATOS
#CITLALI TORRES
from tkinter import *
from tkinter.ttk import *
import mysql.connector

mydb = mysql.connector.connect(         
    host = "localhost",
    user = "CITLALI",
    password = "Ctg24792",
    database = "COVID-19"
)

def INSERTAR():
    mycursor=mydb.cursor()
    sql="INSERT INTO Estados (control,estado) VALUES (%s,%s)"
    NumE=input("Num. de ESTADOS:")
    EST=input("ESTADOS:")
    VAL=(NE,EST)                
    mycursor.execute(sql,val)

    mydb.commit()
    INSERTAR1()
def INSERTAR1():
    mycursor=mydb.cursor()
    sql="INSERT INTO datos (CONFIRMADOS,NEGATIVOS,\
    SOSPECHOSOS) VALUES (%s,%s,%s)"
    CTL=input("CONTROL")
    C=input("CONFIRMADOS:")
    N=input("NEGATIVOS:")        
    S=input("SOSPECHOSOS:")
    val=(CTL,C,N,S)
    mycursor.execute(sql,val)

    mydb.commit()          
    print(mycursor.rowcount,"Se Agrego")

def ESTADOS():          
    print('CONFIRMADOS','NEGATIVOS','SOSPECHOSOS')
    if combo.get()=='SAN LUIS POTOSI':
        mycursor=mydb.cursor()

        sql="SELECT \
            datos.CONFIRMADOS AS ala, \
            datos.NEGATIVOS AS fav, \
            datos.SOSPECHOSOS AS ele, \
            prueba.CONTROLE AS olo \
            FROM datos\
            INNER JOIN prueba ON datos.CONTROL=prueba.CONTROLE where controlE='1'"

        mycursor.execute(sql)
        myresult=mycursor.fetchall()

        for x in myresult:
            print (x)

    if combo.get()=='COAHUILA':
        mycursor=mydb.cursor()

        sql="SELECT \
            datos.Confirmados AS ala, \
            datos.Negativos AS fav, \
            datos.Sospechosos AS ele, \
            prueba.controlE AS olo \
            FROM datos\
            INNER JOIN prueba ON datos.control=prueba.controlE where controlE='2'"

        mycursor.execute(sql)
        myresult=mycursor.fetchall()

        for x in myresult:
            print (x)

    if combo.get()=='TAMAULIPAS':
        mycursor=mydb.cursor()

        sql="SELECT \
            datos.CONFIRMADOS AS ala, \
            datos.NEGATIVOS AS fav, \
            datos.SOSPCHOSOS AS ele, \
            prueba.CONTROLE AS olo \
            FROM datos\
            INNER JOIN prueba ON datos.CONTROL=prueba.CONTROLE where CONTROLE='3'"

        mycursor.execute(sql)
        myresult=mycursor.fetchall()

        for x in myresult:
            print (x)

    if combo.get()=='SONORA':
        mycursor=mydb.cursor()

        sql="SELECT \
            datos.CONFIRMADOS AS ala, \
            datos.NEGATIVOS AS fav, \
            datos.SOSPECHOSOS AS ele, \
            prueba.CONTROLE AS olo \
            FROM datos\
            INNER JOIN prueba ON datos.CONTROL=prueba.CONTROLE where CONTROLE='4'"

        mycursor.execute(sql)
        myresult=mycursor.fetchall()

        for x in myresult:
            print (x)

    if combo.get()=='VERACRUZ':
        mycursor=mydb.cursor()

        sql="SELECT \
            datos.CONFIRMADOS AS ala, \
            datos.NEGATIVOS AS fav, \
            datos.SOSPECHOSOS AS ele, \
            prueba.CONTROLE AS olo \
            FROM datos\
            INNER JOIN prueba ON datos.CONTROL=prueba.CONTROLE where CONTROLE='5'"

        mycursor.execute(sql)
        myresult=mycursor.fetchall()

        for x in myresult:
            print (x)

windows = Tk()
windows.title('CASOS DE COVID-19 EN MEXICO')
windows.geometry("390x170")

foto=PhotoImage(file='COVID-19.jpg')
fondo=Label(windows,image=foto).place(x=0, y=0)

texto=StringVar()
texto.set ('ESTADOS: ')

combo = Combobox(windows)
combo.place(x=10,y=20)                                                     
combo['values'] = [
    'SAN LUIS POTOSI',
    'COAHUILA',
    'TAMAULIPAS',
    'SONORA',
    'VERACRUZ'
    ]
combo.current(0)

boton=Button(windows,command=guardar,text='AGREGAR')
boton2=Button(windows,command=estados,text='ENTER')
etiqueta=Label(windows,textvariable=texto)
etiqueta.place(x=40,y=400)                                                    
boton.place(x=200,y=130)                                                    
boton2.place(x=100,y=130)                                                    

windows.mainloop()
